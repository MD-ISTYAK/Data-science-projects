# Employee-Attrition-analysis

To analyze employee attrition data for XYZ company and create a dashboard that provides insights into why employees are leaving the company. This analysis aims to help XYZ company reduce its attrition rate and make data-driven decisions.

